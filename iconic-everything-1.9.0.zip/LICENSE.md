# Iconic v1.9.0 License

To view Iconic's license, please go to [https://preview.useiconic.com/license/](https://preview.useiconic.com/license/).
